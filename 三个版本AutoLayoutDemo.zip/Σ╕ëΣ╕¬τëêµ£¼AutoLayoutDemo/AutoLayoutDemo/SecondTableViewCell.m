//
//  MyTableViewCell.m
//  AutoLayoutDemo
//
//  Created by dengliwen on 15/6/15.
//  Copyright (c) 2015年 dengliwen. All rights reserved.
//

#import "SecondTableViewCell.h"
#import "Masonry.h"
#import "MMPlaceHolder.h"

@interface SecondTableViewCell ()

@property (nonatomic,strong)UILabel *usernameLabel;
@property (nonatomic,strong)UILabel *titleLabel;
@property (nonatomic,strong)UILabel *contentLabel;
@property (nonatomic,strong)UIImageView *iView;
@property (nonatomic,strong)UILabel *timeLabel;

// titleLabel 是否存在的约束
@property (nonatomic,strong)MASConstraint* contentLabelTopToTitleLabel;
@property (nonatomic,strong)MASConstraint* contentLabelTopToUsernameLabel;
// contentLabel 是否存在的约束
@property (nonatomic,strong)MASConstraint* iViewTopToContentLabel;
@property (nonatomic,strong)MASConstraint* iViewTopToTitleLabel;
// iView 是否存在的约束
@property (nonatomic,strong)MASConstraint* timeLabelTopToContentLabel;
@property (nonatomic,strong)MASConstraint* timeLabelTopToIview;

@end

@implementation SecondTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.usernameLabel = [[UILabel alloc]init];
        self.usernameLabel.font = [UIFont systemFontOfSize:13];
        self.usernameLabel.textColor = [UIColor redColor];
        [self.contentView addSubview:self.usernameLabel];
        
        self.titleLabel = [[UILabel alloc]init];
        self.titleLabel.numberOfLines = 0;
        [self.contentView addSubview:self.titleLabel];
        
        self.contentLabel = [[UILabel alloc]init];
        self.contentLabel.numberOfLines = 0;
        self.contentLabel.font = [UIFont systemFontOfSize:15];
        self.contentLabel.textColor = [UIColor blueColor];
        
        [self.contentView addSubview:self.contentLabel];
        
        self.iView = [[UIImageView alloc]init];
        self.iView.contentMode = UIViewContentModeCenter;
        [self.contentView addSubview:self.iView];
        
        self.timeLabel = [[UILabel alloc]init];
        self.timeLabel.font = [UIFont systemFontOfSize:12];
        //self.timeLabel.font = [UIFont systemFontOfSize:52];
        
        self.timeLabel.textColor = [UIColor grayColor];
        [self.contentView addSubview:self.timeLabel];
        
        
        for (UIView *view in self.contentView.subviews) {
            [view showPlaceHolderWithLineColor:[UIColor greenColor]];
        }
        
        self.usernameLabel.backgroundColor = [UIColor blueColor];
        self.iView.backgroundColor = [UIColor yellowColor];
        self.timeLabel.backgroundColor = [UIColor redColor];
        
        self.titleLabel.backgroundColor = [UIColor orangeColor];
        self.contentLabel.backgroundColor = [UIColor grayColor];
        
        // 设置控件约束
        [self setConstraints];

    }
    return self;
}

- (void)setConstraints
{
    // 边距
    UIEdgeInsets padding = UIEdgeInsetsMake(20, 20, 20, 20);
    
//    CGFloat width = [UIScreen mainScreen].bounds.size.width;
//    // 需要设置contentView 宽度约束 否则会出现警告 ！！！
//    [self.contentView mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.width.equalTo(@(width));
//    }];
    
    // 设置usernameLabel约束
    [self.usernameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.and.left.equalTo(self.contentView).insets(padding);
    }];
    
    // 设置titleLabel约束
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.and.right.equalTo(self.contentView).insets(padding);
        make.top.equalTo(self.usernameLabel.mas_bottom).offset(20);
    }];
    
    // 设置contentLabel约束
    [self.contentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.and.right.equalTo(self.contentView).insets(padding);
        
        // timeLabel top 位置判断约束 因为不能同时存在 所以需要设置优先级
        self.contentLabelTopToTitleLabel = make.top.equalTo(self.titleLabel.mas_bottom).offset(20).priorityHigh();
        self.contentLabelTopToUsernameLabel = make.top.equalTo(self.usernameLabel.mas_bottom).offset(20).priorityLow();
        [self.contentLabelTopToTitleLabel deactivate];
        [self.contentLabelTopToUsernameLabel deactivate];
    }];
    
    // 设置iView约束
    [self.iView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.and.right.equalTo(self.contentView).insets(padding);
        
        // iView top 位置判断约束 因为不能同时存在 所以需要设置优先级
        self.iViewTopToContentLabel = make.top.equalTo(self.contentLabel.mas_bottom).offset(20).priorityHigh();
        self.iViewTopToTitleLabel = make.top.equalTo(self.titleLabel.mas_bottom).offset(20).priorityLow();
        [self.iViewTopToContentLabel deactivate];
        [self.iViewTopToTitleLabel deactivate];
        
        
    }];
    
    // 设置timeLabel约束
    [self.timeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        
        make.left.equalTo(self.contentView).insets(padding);
        
        make.bottom.lessThanOrEqualTo(self.contentView).insets(padding);
        
        //  make.top.equalTo(self.iView.mas_bottom).offset(20);  bug处
        // timeLabel top 位置判断约束 因为不能同时存在 所以需要设置优先级
        self.timeLabelTopToIview = make.top.equalTo(self.iView.mas_bottom).offset(20).priority(750);
        self.timeLabelTopToContentLabel = make.top.equalTo(self.contentLabel.mas_bottom).offset(20).priority(550);
        [self.timeLabelTopToContentLabel deactivate];
        [self.timeLabelTopToIview deactivate];
        
    }];
}

- (void)setModel:(MyModel *)model
{
    _model = model;
    
    self.usernameLabel.text = model.username;
    
    self.titleLabel.text = model.title;
    // 判断titleLabel 是否有内容
    if (model.title.length <= 0) {
        [self.contentLabelTopToUsernameLabel activate];
        [self.contentLabelTopToTitleLabel deactivate];
    }else{
        [self.contentLabelTopToUsernameLabel deactivate];
        [self.contentLabelTopToTitleLabel activate];
    }
    
    
    self.contentLabel.text = model.content;
    // 判断contentLabel 是否有内容
    if (model.content.length <= 0) {
        [self.iViewTopToTitleLabel activate];
        [self.iViewTopToContentLabel deactivate];
    }else{
        [self.iViewTopToContentLabel activate];
        [self.iViewTopToTitleLabel deactivate];
    }
    
    // 判断iView 是否有内容
    if (model.imageName.length <= 0) {
        self.iView.image = nil;
        [self.timeLabelTopToContentLabel activate];
        [self.timeLabelTopToIview deactivate];

    }else{
        self.iView.image = [UIImage imageNamed:model.imageName];
        [self.timeLabelTopToContentLabel deactivate];
        [self.timeLabelTopToIview activate];
    }
    
    self.timeLabel.text = model.time;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
//    [self setConstraints];
    
}

@end
