//
//  MyTableViewCell.h
//  AutoLayoutDemo
//
//  Created by dengliwen on 15/6/15.
//  Copyright (c) 2015年 dengliwen. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyModel.h"
@interface SecondTableViewCell : UITableViewCell

@property (nonatomic,strong) MyModel* model;

@end
