//
//  MyTableViewCell.m
//  AutoLayoutDemo
//
//  Created by dengliwen on 15/6/15.
//  Copyright (c) 2015年 dengliwen. All rights reserved.
//

#import "FirstTableViewCell.h"
#import "Masonry.h"
#import "MMPlaceHolder.h"

@interface FirstTableViewCell ()

@property (nonatomic,strong)UILabel *usernameLabel;
@property (nonatomic,strong)UILabel *titleLabel;
@property (nonatomic,strong)UILabel *contentLabel;
@property (nonatomic,strong)UIImageView *iView;
@property (nonatomic,strong)UILabel *timeLabel;

//
@property (nonatomic,strong)UIButton *zanBtn;

@end

@implementation FirstTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.usernameLabel = [[UILabel alloc]init];
        self.usernameLabel.font = [UIFont systemFontOfSize:13];
        self.usernameLabel.textColor = [UIColor redColor];
        [self.contentView addSubview:self.usernameLabel];
        
        self.titleLabel = [[UILabel alloc]init];
        self.titleLabel.numberOfLines = 0;
        [self.contentView addSubview:self.titleLabel];
        
        self.contentLabel = [[UILabel alloc]init];
        self.contentLabel.numberOfLines = 0;
        self.contentLabel.font = [UIFont systemFontOfSize:15];
        self.contentLabel.textColor = [UIColor blueColor];
        
        [self.contentView addSubview:self.contentLabel];
        
        self.iView = [[UIImageView alloc]init];
        self.iView.contentMode = UIViewContentModeCenter;
        [self.contentView addSubview:self.iView];
        
        self.timeLabel = [[UILabel alloc]init];
        self.timeLabel.font = [UIFont systemFontOfSize:12];
        //self.timeLabel.font = [UIFont systemFontOfSize:52];
        
        self.timeLabel.textColor = [UIColor grayColor];
        [self.contentView addSubview:self.timeLabel];
        
        for (UIView *view in self.contentView.subviews) {
            [view showPlaceHolderWithLineColor:[UIColor greenColor]];
        }
        
        self.usernameLabel.backgroundColor = [UIColor blueColor];
        self.iView.backgroundColor = [UIColor yellowColor];
        self.timeLabel.backgroundColor = [UIColor redColor];
        
        self.titleLabel.backgroundColor = [UIColor orangeColor];
        self.contentLabel.backgroundColor = [UIColor grayColor];
        
        [self setNeedsLayout];
        [self layoutIfNeeded];
    }
    return self;
}

- (void)setModel:(MyModel *)model
{
    _model = model;
    
    self.usernameLabel.text = model.username;
    self.titleLabel.text = model.title;
    self.contentLabel.text = model.content;
//    self.iView.image =  model.imageName.length > 0 ? [UIImage imageNamed:model.imageName] : nil;
    
    if (model.imageName.length <= 0) {
        self.iView.image = nil;
        [self.iView setHidden:YES];
    }else{
        self.iView.image = [UIImage imageNamed:model.imageName];
        [self.iView setHidden:NO];
    }
    
    self.timeLabel.text = model.time;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    // 设置约束
    // 边距
    UIEdgeInsets padding = UIEdgeInsetsMake(20, 20, 20, 20);
    
//    CGFloat width = [UIScreen mainScreen].bounds.size.width;
    // 需要设置contentView 宽度约束 否则会出现警告 ！！！
//    [self.contentView mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.width.equalTo(@(width));
//    }];
    
    [self.usernameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.and.left.equalTo(self.contentView).insets(padding);
    }];
    
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.and.right.equalTo(self.contentView).insets(padding);
        make.top.equalTo(self.usernameLabel.mas_bottom).offset(20);
    }];
    
    [self.contentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.and.right.equalTo(self.contentView).insets(padding);
        make.top.equalTo(self.titleLabel.mas_bottom).offset(20).priorityHigh();
    }];
    
    [self.iView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.and.right.equalTo(self.contentView).insets(padding);
        make.top.equalTo(self.contentLabel.mas_bottom).offset(20);
    }];
    
    [self.timeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.contentView).insets(padding);
//        make.top.equalTo(self.iView.mas_bottom).offset(20);  bug处
        make.bottom.lessThanOrEqualTo(self.contentView).insets(padding);
        make.top.equalTo(self.iView.mas_bottom).offset(20).priorityHigh();
    
    }];
    
    [self.superview layoutIfNeeded];
    
}

@end
