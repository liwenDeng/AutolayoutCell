//
//  MyModel.h
//  AutoLayoutDemo
//
//  Created by dengliwen on 15/6/15.
//  Copyright (c) 2015年 dengliwen. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MyModel : NSObject

@property (nonatomic,strong)NSString* title;
@property (nonatomic,strong)NSString* content;
@property (nonatomic,strong)NSString* username;
@property (nonatomic,strong)NSString* time;
@property (nonatomic,strong)NSString* imageName;

@end
