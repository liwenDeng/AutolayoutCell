//
//  MyTableViewController.m
//  AutoLayoutDemo
//
//  Created by dengliwen on 15/6/15.
//  Copyright (c) 2015年 dengliwen. All rights reserved.
//

#import "FirstTableViewController.h"
#import "MyModel.h"
#import "MJExtension.h"
#import "FirstTableViewCell.h"

@interface FirstTableViewController ()

@property (nonatomic,strong)NSMutableArray* models;

@end

@implementation FirstTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.tableView.estimatedRowHeight = 200;
    self.tableView.rowHeight = UITableViewAutomaticDimension;

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return self.models.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    FirstTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell" ];
    if (!cell) {
        cell = [[FirstTableViewCell alloc]initWithStyle:(UITableViewCellStyleDefault) reuseIdentifier:@"Cell"];
    }
    cell.model = self.models[indexPath.row];
    return cell;
}


- (NSMutableArray *)models
{
    if (!_models) {
        _models = [NSMutableArray array];
        // 处理数据源
        NSString *dataFilePath = [[NSBundle mainBundle]pathForResource:@"data" ofType:@"json"];
        NSData *data = [NSData dataWithContentsOfFile:dataFilePath];
        NSDictionary *rootDic = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil ];
        NSArray *feedDics = [rootDic objectForKey:@"feed"];
        for (NSDictionary *modelDic in feedDics) {
            // 使用MJExtension 将字典转换为数据模型
            MyModel *model = [MyModel objectWithKeyValues:modelDic];
            [_models addObject:model];
        }
    }
    return _models;
}
@end
