//
//  MyTableViewCell.m
//  AutoLayoutDemo
//
//  Created by dengliwen on 15/6/15.
//  Copyright (c) 2015年 dengliwen. All rights reserved.
//

#import "ThirdTableViewCell.h"
#import "Masonry.h"
#import "MMPlaceHolder.h"

@interface ThirdTableViewCell ()

@property (nonatomic,strong)UIView* gUser;
@property (nonatomic,strong)UIView* gTitle;
@property (nonatomic,strong)UIView* gContent;
@property (nonatomic,strong)UIView* gIView;
@property (nonatomic,strong)UIView* gTime;

@property (nonatomic,strong)UILabel *usernameLabel;
@property (nonatomic,strong)UILabel *titleLabel;
@property (nonatomic,strong)UILabel *contentLabel;
@property (nonatomic,strong)UIImageView *iView;
@property (nonatomic,strong)UILabel *timeLabel;

// 约束
@property (nonatomic,strong)MASConstraint* hideGIView;  // 隐藏gIView
@property (nonatomic,strong)MASConstraint* hideGTitle;  // 隐藏gTitle
@property (nonatomic,strong)MASConstraint* hideGContent;// 隐藏gContent

@property (nonatomic,strong)UIButton *zanBtn;

@end

@implementation ThirdTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        self.gUser = [[UIView alloc]init];
        self.gTitle = [[UIView alloc]init];
        self.gContent = [[UIView alloc]init];
        self.gIView = [[UIView alloc]init];
        self.gTime = [[UIView alloc]init];
        
        [self.contentView addSubview:self.gUser];
        [self.contentView addSubview:self.gTitle];
        [self.contentView addSubview:self.gContent];
        [self.contentView addSubview:self.gIView];
        [self.contentView addSubview:self.gTime];
        
        
        self.usernameLabel = [[UILabel alloc]init];
        self.usernameLabel.font = [UIFont systemFontOfSize:13];
        self.usernameLabel.textColor = [UIColor redColor];
        [self.gUser addSubview:self.usernameLabel];
        
        self.titleLabel = [[UILabel alloc]init];
        self.titleLabel.numberOfLines = 0;
        [self.gTitle addSubview:self.titleLabel];
        
        self.contentLabel = [[UILabel alloc]init];
        self.contentLabel.numberOfLines = 0;
        self.contentLabel.font = [UIFont systemFontOfSize:15];
        self.contentLabel.textColor = [UIColor blueColor];
        [self.gContent addSubview:self.contentLabel];
        
        self.iView = [[UIImageView alloc]init];
        self.iView.contentMode = UIViewContentModeCenter;
        [self.gIView addSubview:self.iView];
        
        self.timeLabel = [[UILabel alloc]init];
        self.timeLabel.font = [UIFont systemFontOfSize:12];
        //self.timeLabel.font = [UIFont systemFontOfSize:52];
        
        self.timeLabel.textColor = [UIColor grayColor];
        [self.gTime addSubview:self.timeLabel];
        
        [self setConstains];

//        for (UIView *view in self.contentView.subviews) {
//            [view showPlaceHolderWithLineColor:[UIColor greenColor]];
//        }
        
//        self.usernameLabel.backgroundColor = [UIColor blueColor];
//        self.iView.backgroundColor = [UIColor yellowColor];
//        self.timeLabel.backgroundColor = [UIColor redColor];
//        
//        self.titleLabel.backgroundColor = [UIColor orangeColor];
//        self.contentLabel.backgroundColor = [UIColor grayColor];
        
    }
    return self;
}

- (void)setModel:(MyModel *)model
{
    _model = model;
    
    self.usernameLabel.text = model.username;
    self.titleLabel.text = model.title;
    self.contentLabel.text = model.content;
    
    [self.hideGIView deactivate];
    [self.hideGTitle deactivate];
    [self.hideGContent deactivate];
    
    
    if (model.title.length <= 0){
        [self.hideGTitle activate];
    }else{
        [self.hideGTitle deactivate];
    }
    
    if (model.content.length <= 0) {
        [self.hideGContent activate];
    }else{
        [self.hideGContent deactivate];
    }
    
    if (model.imageName.length <= 0) {
        self.iView.image = nil;
        [self.hideGIView activate];

    }else{
        self.iView.image = [UIImage imageNamed:model.imageName];
        [self.hideGIView deactivate];
    }
    
    self.timeLabel.text = model.time;
}

- (void)setConstains
{
    CGFloat width = [UIScreen mainScreen].bounds.size.width;
    
    // 需要设置contentView 宽度约束 否则可能会出现警告 ！！！
    [self.contentView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.equalTo(@(width));
    }];

    [self.gUser mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.and.top.and.right.equalTo(self.contentView);
    }];
    
    [self.gTitle mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.and.right.equalTo(self.contentView);
        make.top.equalTo(self.gUser.mas_bottom);
        self.hideGTitle = make.height.equalTo(@0).priority(UILayoutPriorityRequired);
        [self.hideGTitle deactivate];
    }];
    
    [self.gContent mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.and.right.equalTo(self.contentView);
        make.top.equalTo(self.gTitle.mas_bottom);
        
        self.hideGContent = make.height.equalTo(@0).priority(UILayoutPriorityRequired);
        [self.hideGContent deactivate];
    }];
    
    [self.gIView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.and.right.equalTo(self.contentView);
        make.top.equalTo(self.gContent.mas_bottom);
        
        self.hideGIView = make.height.equalTo(@0).priority(UILayoutPriorityRequired);
        [self.hideGIView deactivate];
    }];
    
    [self.gTime mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.and.right.and.bottom.equalTo(self.contentView);
        make.top.equalTo(self.gIView.mas_bottom);
    }];
    
    
    
    // 设置约束
    // 边距
    UIEdgeInsets padding = UIEdgeInsetsMake(20, 20, 0, 20);

    [self.usernameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self.gUser).insets(padding).priorityLow();
    }];
    
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        // 由于 内部View 高度为0 时，与外部View的间距不能大于 0 ，因此，需要设置低优先级，
        make.top.and.bottom.equalTo(self.gTitle).insets(padding).priorityLow();
        make.left.and.right.equalTo(self.gTitle).insets(padding);
    }];
    
    [self.contentLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        // 由于 内部View 高度为0 时，与外部View的间距不能大于 0 ，因此，需要设置低优先级，
        make.top.and.bottom.equalTo(self.gContent).insets(padding).priorityLow();
        make.left.and.right.equalTo(self.gContent).insets(padding);
        
    }];
    
    [self.iView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self.gIView).insets(padding).priorityLow();
        // 由于 内部View 高度为0 时，与外部View的间距不能大于 0 ，因此，需要设置低优先级，
        make.top.and.bottom.equalTo(self.gIView).insets(padding).priorityLow();
        make.left.and.right.equalTo(self.gIView).insets(padding);
    }];
    
    [self.timeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self.gTime).insets(UIEdgeInsetsMake(20, 20, 20, 20)).priorityLow();
        
    }];
    
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
}

@end
